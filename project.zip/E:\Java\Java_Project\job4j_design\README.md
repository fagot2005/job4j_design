[![Build Status](https://travis-ci.org/fagot2005/job4j_design.svg?branch=master)](https://travis-ci.org/fagot2005/job4j_design)
[![codecov](https://codecov.io/gh/fagot2005/job4j_design/branch/master/graph/badge.svg)](https://codecov.io/gh/fagot2005/job4j_design)


# job4j_design
Start of this module 25/06/2020
