package generic;

public class Role extends Base {
    protected Role(String id) {
        super(id);
    }
}
